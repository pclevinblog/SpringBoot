package com.example.springbootwecontrollerrequestparampathvariabledemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWeControllerRequestparamPathvariableDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootWeControllerRequestparamPathvariableDemoApplication.class, args);
    }

}
