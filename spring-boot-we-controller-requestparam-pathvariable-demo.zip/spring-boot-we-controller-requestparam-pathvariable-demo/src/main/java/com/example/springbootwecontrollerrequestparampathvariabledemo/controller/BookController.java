package com.example.springbootwecontrollerrequestparampathvariabledemo.controller;


import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/books")
public class BookController {

    @GetMapping("/test1/{id}")
    public String pathVariableTest1(@PathVariable String id) {
        return "@PathVariable pathVariableTest1. id=" + id;
    }

    @GetMapping("/test2/{id}")
    public String pathVariableTest2(@PathVariable(name = "id") String bookId) {
        return "@PathVariable(name=\"id\") pathVariableTest2. bookId=" + bookId;
    }

    @GetMapping("/test3/{id}")
    public String pathVariableTest3(@PathVariable(value = "id") String bookId) {
        return "@PathVariable(value=\"id\")  pathVariableTest3. bookId=" + bookId;
    }

    @GetMapping(value = {"/test4/{name}", "/test4/{name}/{id}"})
    public String pathVariableTest4(@PathVariable String name, @PathVariable(required = false) String id) {
        return "@PathVariable pathVariableTest4. name=" + name + " ,id=" + id;
    }

    @GetMapping("/test5/{id}-{name}-{price}")
    public String pathVariableTest5(@PathVariable(value = "id") String bookId,
                                    @PathVariable String name,
                                    @PathVariable String price) {
        return "@PathVariable pathVariableTest5. bookId=" + bookId + ",name=" + name + ",price=" + price;
    }

    @GetMapping("/test6/{id}/{name}/{price}")
    public String pathVariableTest6(@PathVariable(value = "id") String bookId,
                                    @PathVariable String name,
                                    @PathVariable String price) {
        return "@PathVariable pathVariableTest6. bookId=" + bookId + ",name=" + name + ",price=" + price;
    }


    @GetMapping(value = "/test8/{id}/{name}")
    public String pathVariableTest8(@PathVariable Map<String, String> bookMsp) {
        return "PathVariable Map pathVariableTest8 ,bookId=" + bookMsp.get("id") + ",name=" + bookMsp.get("name");
    }



    @GetMapping("/test10/list")
    public String requestParamTest10(@RequestParam String name, @RequestParam String id) {
        return "@RequestParam requestParamTest10. name=" + name + " ,id=" + id;
    }

    @PostMapping("/test11/list")
    public String requestParamTest11(@RequestParam String name, @RequestParam String id) {
        return "@RequestParam post requestParamTest11. name=" + name + " ,id=" + id;
    }


    @GetMapping("/test12/{id}/{name}")
    public String pathVariableTest12(@PathVariable(value = "id") String bookId,
                                    @PathVariable String name,
                                    @RequestParam String price) {
        return "@PathVariable and @RequestParam pathVariableTes12. bookId=" + bookId + ",name=" + name + ",price=" + price;
    }

}
