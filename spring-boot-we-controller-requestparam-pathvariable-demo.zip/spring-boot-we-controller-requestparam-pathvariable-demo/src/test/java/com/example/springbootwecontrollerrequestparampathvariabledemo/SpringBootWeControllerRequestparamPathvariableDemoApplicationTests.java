package com.example.springbootwecontrollerrequestparampathvariabledemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWeControllerRequestparamPathvariableDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
