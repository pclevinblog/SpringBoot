package com.example.springbootymltestdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootymltestdemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
