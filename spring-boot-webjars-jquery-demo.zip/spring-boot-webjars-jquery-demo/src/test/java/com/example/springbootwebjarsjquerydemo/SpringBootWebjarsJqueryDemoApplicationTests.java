package com.example.springbootwebjarsjquerydemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebjarsJqueryDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
