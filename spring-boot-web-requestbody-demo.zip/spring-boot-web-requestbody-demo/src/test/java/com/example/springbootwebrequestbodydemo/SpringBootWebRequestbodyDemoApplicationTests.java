package com.example.springbootwebrequestbodydemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebRequestbodyDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
