package com.example.springbootwebrequestbodydemo.controller;


import com.example.springbootwebrequestbodydemo.model.Book;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/books")
public class BookController {

    @RequestMapping(value = "/test1",
            method = RequestMethod.POST)//produces= MediaType.APPLICATION_JSON_VALUE
    public @ResponseBody
    Book bodyTest1(@RequestBody Book book) {
        return book;
    }

    @RequestMapping(value = "/test2",
            method = RequestMethod.POST,
            produces=MediaType.APPLICATION_XML_VALUE)
    public @ResponseBody
    Book bodyTest2(@RequestBody Book book) {
        return book;
    }
}
