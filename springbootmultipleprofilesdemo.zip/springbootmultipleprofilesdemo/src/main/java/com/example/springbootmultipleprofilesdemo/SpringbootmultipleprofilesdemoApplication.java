package com.example.springbootmultipleprofilesdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootmultipleprofilesdemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootmultipleprofilesdemoApplication.class, args);
    }

}
