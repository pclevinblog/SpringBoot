package com.example.springbootmultipleprofilesdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootmultipleprofilesdemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
