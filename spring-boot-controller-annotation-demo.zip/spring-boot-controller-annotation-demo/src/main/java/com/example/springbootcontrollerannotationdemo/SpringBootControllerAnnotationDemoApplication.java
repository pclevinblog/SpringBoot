package com.example.springbootcontrollerannotationdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootControllerAnnotationDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootControllerAnnotationDemoApplication.class, args);
    }

}
