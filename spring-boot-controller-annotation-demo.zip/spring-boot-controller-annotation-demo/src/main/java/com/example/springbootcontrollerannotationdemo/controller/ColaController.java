package com.example.springbootcontrollerannotationdemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ColaController {
    @RequestMapping("/cola")
    public String gotocola(){
        return "colaArea";
    }
}
