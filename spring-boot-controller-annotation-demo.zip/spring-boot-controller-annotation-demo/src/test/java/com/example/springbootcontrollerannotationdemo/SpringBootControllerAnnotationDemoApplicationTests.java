package com.example.springbootcontrollerannotationdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootControllerAnnotationDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
