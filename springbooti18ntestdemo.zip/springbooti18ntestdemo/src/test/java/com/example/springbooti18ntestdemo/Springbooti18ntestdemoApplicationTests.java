package com.example.springbooti18ntestdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbooti18ntestdemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
