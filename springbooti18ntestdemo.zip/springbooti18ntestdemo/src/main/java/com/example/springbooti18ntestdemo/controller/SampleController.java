package com.example.springbooti18ntestdemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Locale;

@RestController
public class SampleController {
    @Autowired
    private MessageSource messageSource;

    @RequestMapping("/index")
    public String index(@RequestParam("lang") String langStr){
        Locale locale = Locale.ROOT;//預設使用，測試用的會使用message.properties
        if("zh".equals(langStr)){
            locale = Locale.TAIWAN;//設定會使用message_zh_TW.properties
        } else if("en".equals(langStr)){
            locale = Locale.US;//設定會使用message_en_US.properties
        }
        String str =  messageSource.getMessage("spring.boot.hello.world", null, locale);
        System.out.println(str);
        return str;
    }
}
