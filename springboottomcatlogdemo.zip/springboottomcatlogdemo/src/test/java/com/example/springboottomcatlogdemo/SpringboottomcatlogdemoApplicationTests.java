package com.example.springboottomcatlogdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringboottomcatlogdemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
