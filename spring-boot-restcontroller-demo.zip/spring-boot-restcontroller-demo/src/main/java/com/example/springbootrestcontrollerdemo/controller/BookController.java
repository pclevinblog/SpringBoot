package com.example.springbootrestcontrollerdemo.controller;

import com.example.springbootrestcontrollerdemo.model.Book;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/book")
public class BookController {

    @RequestMapping("/index")
    public Object index(){

        return "get book url: http://localhost:8080/book/1 ";
    }

    @RequestMapping("/{bookId}")
    public Object getOne(@PathVariable int bookId){
        System.out.println(bookId);
        Book book = new Book();
        book.setId(bookId);
        book.setName("test book");
        book.setPrice("1000");

        Map<String, Book> books = new HashMap<>();
        books.put("book", book);
        return books;
    }

}
