package com.example.springbootrestcontrollerdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestcontrollerDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootRestcontrollerDemoApplication.class, args);
    }

}
