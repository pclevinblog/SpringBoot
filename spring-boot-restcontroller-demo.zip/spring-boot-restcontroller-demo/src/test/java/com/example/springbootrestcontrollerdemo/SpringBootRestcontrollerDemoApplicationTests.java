package com.example.springbootrestcontrollerdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestcontrollerDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
