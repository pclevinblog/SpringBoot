package com.example.springbootwebrequestmappingdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebRequestmappingDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
