package com.example.springbootwebrequestmappingdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWebRequestmappingDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootWebRequestmappingDemoApplication.class, args);
    }

}
