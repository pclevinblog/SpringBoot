package com.example.springbootwebrequestmappingdemo.controller;


import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping(value="/book2")
public class Book2Controller {

    @RequestMapping(value = "/test10/{id}",method =  RequestMethod.GET)
    public String requestMappingTest10(@PathVariable String id){
        return "@RequestMapping(\"/test10/{id}\") requestMappingTest10 Test10 . id=" + id;
    }
}
