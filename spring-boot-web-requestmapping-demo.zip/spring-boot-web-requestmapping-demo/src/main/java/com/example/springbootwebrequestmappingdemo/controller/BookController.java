package com.example.springbootwebrequestmappingdemo.controller;


import com.example.springbootwebrequestmappingdemo.model.Book;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping(value="/books",name="bc")
public class BookController {

    @RequestMapping(name="test10",value = "/test10/{id}",method =  RequestMethod.GET)
    public String requestMappingTest10(@PathVariable String id){
        return "@RequestMapping(\"/test10/{id}\") requestMappingTest10 Test10 . id=" + id;
    }

    @RequestMapping("/test1/{id}")
    public String requestMappingTest1(@PathVariable String id) throws NoSuchMethodException {
        RequestMapping requestMapping =
                AnnotationUtils.getAnnotation(
                        BookController.class.getMethod("requestMappingTest1", String.class)
                        , RequestMapping.class
                );
        return "@RequestMapping(\"/test1/{id}\") requestMapping Test1 . RequestMapping=" + requestMapping;
    }

    @RequestMapping(value = "/test2/{id}",method =  RequestMethod.GET)
    public String requestMappingTest2(@PathVariable String id){
        return "@RequestMapping(\"/test2/{id}\") requestMappingTest2 Test2 . id=" + id;
    }



    @RequestMapping(value = "/test3" ,method =  RequestMethod.POST ,consumes="application/json")
    public String requestMappingTest3(@RequestBody Book book){
        return "@RequestMapping(\"/test3\") requestMappingTest3 Test3 . book=" + book;
    }

    @RequestMapping(value = "/test4" ,method =  RequestMethod.POST ,produces="application/json;charset=UTF-8")
    public @ResponseBody Book requestMappingTest4(@RequestBody Book book){
        return  book;
    }

    @RequestMapping(value = "/test5/{id}",method =  RequestMethod.GET,params="name=java")
    public String requestMappingTest5(@PathVariable String id){
        return "@RequestMapping(\"/test5\") requestMappingTest5 Test5 . id="+id;
    }

    @RequestMapping(value = "/test6",method =  RequestMethod.POST,headers = {"Content-Type=application/json","Host=localhost:8080"})
    public @ResponseBody Book requestMappingTest6(@RequestBody Book book){
        return  book;
    }


}
