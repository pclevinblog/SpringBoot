package com.example.springbootwebrequestmappingdemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/jsp")
public class JspController {

    @GetMapping("/books/{jspPageName}")
    public String jspbooksPage(@PathVariable String jspPageName){
        System.out.println(jspPageName);
        return "books/"+jspPageName;
    }

}
