package com.example.springbootwebcontrollermethdmappingdemo.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/book")
public class BookController {

    @GetMapping("/{name}")
    public String getMappingTest(@PathVariable String name){
        return "method getMapping Test. name=" + name;
    }

    @PostMapping("/{name}")
    public String postMappingTest(@PathVariable String name){
        return "method PostMapping Test. name=" + name;
    }

    @PutMapping("/{name}")
    public String putMappingTest(@PathVariable String name){
        return "method PutMapping Test. name=" + name;
    }
    @DeleteMapping("/{name}")
    public String deleteMappingTest(@PathVariable String name){
        return "method DeleteMapping Test. name=" + name;
    }
    @PatchMapping("/{name}")
    public String patchMappingTest(@PathVariable String name){
        return "method PatchMapping Test. name=" + name;
    }
}
