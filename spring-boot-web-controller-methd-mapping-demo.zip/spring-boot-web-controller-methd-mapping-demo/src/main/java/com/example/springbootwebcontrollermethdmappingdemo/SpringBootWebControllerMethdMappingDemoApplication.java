package com.example.springbootwebcontrollermethdmappingdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWebControllerMethdMappingDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootWebControllerMethdMappingDemoApplication.class, args);
    }

}
