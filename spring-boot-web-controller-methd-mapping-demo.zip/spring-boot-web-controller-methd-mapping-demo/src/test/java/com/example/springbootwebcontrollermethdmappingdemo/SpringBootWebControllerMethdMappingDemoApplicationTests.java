package com.example.springbootwebcontrollermethdmappingdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebControllerMethdMappingDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
