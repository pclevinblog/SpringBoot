package com.example.springboottestmockmvcdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootTestMockmvcDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootTestMockmvcDemoApplication.class, args);
    }

}
