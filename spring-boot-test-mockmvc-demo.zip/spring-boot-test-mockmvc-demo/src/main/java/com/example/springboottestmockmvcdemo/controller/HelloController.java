package com.example.springboottestmockmvcdemo.controller;
import org.springframework.web.bind.annotation.*;


@RestController
public class HelloController {

    @RequestMapping(value = "/test1")
    public String test1() {
        System.out.println("HelloController -- Spring boot test");
        return "Spring boot test";
    }

}
