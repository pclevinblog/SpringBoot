package com.example.springboottestmockmvcdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootTestMockmvcDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
