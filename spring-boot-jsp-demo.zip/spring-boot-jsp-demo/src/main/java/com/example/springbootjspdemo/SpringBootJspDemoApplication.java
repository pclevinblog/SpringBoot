package com.example.springbootjspdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJspDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootJspDemoApplication.class, args);
    }

}
