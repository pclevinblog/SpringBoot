package com.example.springbootjspdemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class JspController {

    @GetMapping("/{jspPageName}")
    public String jspPage(@PathVariable String jspPageName){
        System.out.println(jspPageName);
        return jspPageName;
    }

    @GetMapping("/books/{jspPageName}")
    public String jspbooksPage(@PathVariable String jspPageName){
        System.out.println(jspPageName);
        return "books/"+jspPageName;
    }

}
