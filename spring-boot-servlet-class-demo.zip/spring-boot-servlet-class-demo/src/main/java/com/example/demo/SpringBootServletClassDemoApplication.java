package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootServletClassDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootServletClassDemoApplication.class, args);
    }

}
