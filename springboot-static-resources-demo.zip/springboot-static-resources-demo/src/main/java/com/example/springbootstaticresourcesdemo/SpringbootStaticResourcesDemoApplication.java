package com.example.springbootstaticresourcesdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootStaticResourcesDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootStaticResourcesDemoApplication.class, args);
    }

}
