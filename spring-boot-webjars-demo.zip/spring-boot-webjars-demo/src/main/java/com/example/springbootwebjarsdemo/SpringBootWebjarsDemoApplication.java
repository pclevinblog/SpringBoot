package com.example.springbootwebjarsdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWebjarsDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootWebjarsDemoApplication.class, args);
    }

}
