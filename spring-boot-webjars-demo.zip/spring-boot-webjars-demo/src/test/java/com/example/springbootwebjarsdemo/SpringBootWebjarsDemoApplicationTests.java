package com.example.springbootwebjarsdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebjarsDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
