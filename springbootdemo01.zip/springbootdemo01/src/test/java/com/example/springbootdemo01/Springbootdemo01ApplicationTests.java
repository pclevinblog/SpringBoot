package com.example.springbootdemo01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbootdemo01ApplicationTests {

    @Test
    void contextLoads() {
    }

}
